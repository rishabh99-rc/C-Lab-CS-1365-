/*  Registration Number :- 201900319 (Rishabh Chauhan)

 Algorithm :-->
 
 Step 0-Start
 
 Step 1-Create a base class by name of Figure.
 
 Step 2-Inside the class declare two variable and an input function to take value input and an virtual function to give out area.
 
 Step 3-Create a class Rectangle and derive the base class as public and give a public function to compute a rectangle area.
 
 Step 4-Create a class Triangle and derive the base class as public and give a public function to compute a triangle area.
 
 Step 5-Inside the main function declare a pointer of Base class .
 
 Step 6-Now create two separate objects of derived class and take variable data input.
 
 Step 7-Now use the pointer and pass them to pointer and call the compute area function.
 
 Step-8-Stop
 */

#include<iostream>
#include<stdio.h>
#include<string.h>

using namespace std;

//  class Figure
class Figure
{
    public:
    double height,base;

    //  constructor to assign initial values to height and base
    Figure()
    {	 	  	 	   	      	    	  	 	
        height=0;
        base=0;
    }

    //  get_data() function to get values of height and base
    void get_data()
    {
        cout<<"\nEnter Height and Base to compute Area :";
        cin>>height>>base;
    }

    //  declaration of virtual function area()
    virtual void area()
    {
    }
};

//class triangle inheriting class Figure
class Triangle : public Figure
{
    public:

    //redefining function area()
    void area()
    {
        cout<<height;
        cout<<"\nArea of Triangle = "<<(height*base)/2;
    }
};

//class Rectangle inheriting class Figure
class Rectangle : public Figure
{
    public:

    //redefining function area()
    void area()
    {	 	  	 	   	      	    	  	 	
        cout<<"\nArea of Rectangle = "<<height*base;
    }
};

int main()
{

    Figure *f;
    
    Triangle t;
    t.get_data();
    f=&t;
    f->area();
    
    Rectangle r;
    r.get_data();
    f=&r;
    f->area();
    
    return 0;
}

/*  Expected (Input/Output) :-->
                                                                                
Enter Height and Base to compute Area :2                                        
3                                                                               
2                                                                               
Area of Triangle = 3                                                            
Enter Height and Base to compute Area :4                                        
5                                                                               
Area of Rectangle = 3                                                                                  

*/	 	  	 	   	      	    	  	 	
