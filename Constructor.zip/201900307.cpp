/*  Registation Number : 201900307 (Rishabh Chauhan)

ALGORITHM :-->

Step 1: Start

Step 2: Declare an object called 'STRING'

Step 3: Declare a character array(string).

Step 4: Declare the default constructor intiliazing the string to NULL.

Step 5: Declare a parameterized constructor passing a string to the constructor and initialize the string of the object to the string passed in the constructor

Step 6: Declare a copy constructor copying the contents of existing object to the new object.

Step 7: Using friend ostream function overload '<<' operator.

Step 8: Create a funtion 'operator +()' passing the object as ththe parameter to it and overload the + operator in it.

Step 9: In the main function declare three objects of class STRINGre

Step 10: Intialize the object 1 string to SMIT

Step 11: Intialize the object 2 string to MAJITAR

Step 12: Intialize the object 3 by adding ob1+obj2(using the + operator).

Step 13: Display all the strings.

Step 14: Stop
*/

#include<iostream>
#include<string.h>
using namespace std;

class STRING
{	 	  	 	   	      	    	  	 	
    char  str[100];
    public:
    
    STRING()
    {
            strcpy(str," ");
    }
    
    STRING(char *s1)
    {
        strcpy(str,s1);
    }
    
    STRING(STRING& s)
    {
        strcpy(str,s.str);
    }
    
    STRING operator +(STRING );
    
    friend ostream& operator <<(ostream& c,STRING s1)
    {
        c<<s1.str;
        cout<<endl;
        return c;
    }
};
    
int main()
{
    STRING s1,s2,s3;
    
    s1=(char *)"SMIT";
    s2=(char *)"MAJITAR";
    s3=s1+s2;
    
    cout<<"The concatenated string is ";
    cout<<s3<<"\n";
    
    return 0;
}	 	  	 	   	      	    	  	 	

STRING STRING::operator +(STRING s)
{
    strcat(str,s.str);
    return (*this);
}

/*  Expected(INPUT/OUTPUT) :-->

The concatenated string is SMITMAJITAR   

*/