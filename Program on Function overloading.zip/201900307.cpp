/*   Registration number : 201900307

ALGORITHM :-->

Step 1: Start

Step 2: Declare a class named TIME & Declare one float and one int variables

Step 3: Read the values of hours and minutes

Step 4: Create a member fucntion called TIME add()
        Step 4.1: IF temp.minutes>=60
                Begin
                    temp.hours++;
                    temp.minutes=60;
                End(if loop)

Step 5: Create another called TIME add()
        Step 5.1: IF temp.minutes>=60
                Begin
                    temp.hours++;
                    temp.minutes-=60;
                End(if loop)

Step 6: Define main()
        Step 6.1: Read the values
        STep 6.2: Display the values

Step 7: Stop
*/

#include<iostream>
using namespace std;

class TIME
{
    float hours;
    int minutes;
    
    public:
    
    void read()         // To read the number of hrs & min
    {	 	  	 	   	      	    	  	 	
        cout<<"Enter the number of hours: ";
        cin>>hours;
        cout<<"Enter the number of minutes: ";
        cin>>minutes;
    }
    
    void display()      // To display the number of hrs & min
    {
        cout<<hours<<"hours"<<minutes<<"minutes"<<endl;
    }
    
    TIME add (int x)    // To add x into minutes
    {
        TIME temp(*this);
        temp.minutes = minutes+x;
        if(temp.minutes>=60)
        {
            temp.hours++;
            temp.minutes-=60;
        }
        return temp;
    }
    
    TIME add(TIME T1)   // To add T1 into minutes   // Function Overloading
    {
        TIME temp(*this);
        temp.hours += T1.hours;
        temp.minutes += T1.minutes;
        if(temp.minutes>=60)
        {
            temp.hours++;
            temp.minutes-=60;
        }
        return temp;
    }
    
    TIME (){hours = minutes =0;}	 	  	 	   	      	    	  	 	
    TIME (const TIME &s1)
    {
        hours = s1.hours;
        minutes = s1.minutes;
    }
};


int main()
{
    TIME T1, T2, r;     // Declaring the objects
    int x;
    
    cout<<"***** ENTER THE VALUES ***** \n";
    cout<<"Time 1: \n"; T1.read();
    cout<<"\nTime 2: \n"; T2.read();
    
    r = T1.add(T2);
    cout<<"\nOn adding both the time (T1 + T2): ";
    r.display();
    
    cout<<"\nEnter minutes to add (x): ";
    cin>>x;
    
    cout<<"\nOn Adding minutes to T1 (T1 +x): \n";
    r = T1.add(x);
    r.display();

    return 0;
}

/* INPUT AND OUTPUT

***** ENTER THE VALUES *****                                                    
Time 1:                                                                         
Enter the number of hours: 8                                                    
Enter the number of minutes: 54                                                 
                                                                                
Time 2:                                                                         
Enter the number of hours: 86                                                   
Enter the number of minutes: 54                                                 
                                                                                
On adding both the time (T1 + T2): 95hours48minutes                             
                                                                                
Enter minutes to add (x): 25                                                    
                                                                                
On Adding minutes to T1 (T1 +x):                                                
9hours19minutes         
*/	 	  	 	   	      	    	  	 	
