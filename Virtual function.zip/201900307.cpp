/*      Registration Number : 201900307 (Rishabh Chauhan)

Algorithm : Virtual_function

Step 1 : Start

Step 2 : Declare a class convert
    Step 2.1: In protected member funtion:
        Step 2.1.1: Declare double variables as val1, val2;
        
    Step 2.2: In public memeber function: 
        Step 2.2.1: Declare function convert(), getconvert() & getinit()

Step 3 : class lit_to_gal declared and function compute called for conversions.     // Liters to Gallons Convertion

Step 4 : class far_to_cel declared and funciton compute called for conversions.     // Fahrenheit to Celsius Convertion

Step 5 : In the Main Function:
    Step 5.1: Declare an object num
    Step 5.2: Get the input from the user
    Step 5.3: Use lit_to_gal class to convert liters to gallons & far_to_cel to convert farenheit to celsius

Step 6 : Display Converted Values.

Step 7 : Stop
*/

#include <iostream>
using namespace std;

class convert
{
    protected:
        double val1;
        double val2;
    
    public: convert(double i)
    {	 	  	 	   	      	    	  	 	
        val1 = i;
    }
    
    double getconvert()
    {
        return val2;
    }
    
    double getinit()
    {
        return val1;
    }
    
    virtual void compute() = 0;
};

class lit_to_gal : public convert   // Liters to Gallons
{
    public:
    lit_to_gal(double i) : convert(i)
    {
    }

    void compute()
    {
        val2 = val1 / 3.7854;
    }

    
};

class far_to_cel : public convert       // Fahrenheit to Celsius
{
    public:
    far_to_cel(double i) : convert(i)
    {	 	  	 	   	      	    	  	 	
    }
    void compute()
    {
        val2 = (val1-32) / 1.8;
    }
};

int main()
{
    int num;
    convert *p;
    
    cout<<"Enter LITERS for conversion to GALLONS : ";
    cin>>num;
    lit_to_gal lgob(num);
    
    cout<<"\nEnter FAHRENHEIT for conversion to CELSIUS : ";
    cin>>num;
    far_to_cel fcob(num);

    p = &lgob;
    cout<<"\n";
    cout<< p->getinit() << " Liters is ";
    p->compute();
    cout<< p->getconvert()<< " Gallons\n";
    
    p = &fcob;
    cout<< p->getinit() << " degree Fahrenheit is ";
    p->compute();
    cout<< p->getconvert()<< " degree Celsius\n";
    
    return 0;
}

/*  Expected (Input/Output) :-->

Enter LITERS for conversion to GALLONS : 3                                      
                                                                                
Enter FAHRENHEIT for conversion to CELSIUS : 96                                 
                                                                                
3 Liters is 0.792519 Gallons                                                    
96 degree Fahrenheit is 35.5556 degree Celsius  
*/	 	  	 	   	      	    	  	 	
