/*  Registration Number : 201900307  (Rishabh Chauhan)

Algorithm :-->

Step 0: START

Step 1: declare template <typename T, int size>

Step 2: declare class Stack
    Step 2.1: private:
        Step 2.1.1: T* stack
        Step 2.1.2: int top
    
    Step 2.2:  public:
        Step 2.2.1: Stack()
        Step 2.2.2: ~Stack()
        Step 2.2.3: bool empty()
        Step 2.2.4: void push(T element)
        Step 2.2.5: T pop()
        Step 2.2.6: void display()

Step 3: declare template<typename T, int size>
    Step 3.1: Stack<T, size> :: Stack()
       Step 3.1.1: stack = new T[size]
       Step 3.1.2: top = -1

Step 4: declare template<typename T, int size>
    Step 4.1: Stack<T, size> :: ~Stack()
       Step 4.1.1: delete[] stack

Step 5: declare template<typename T,  int size>
    Step 5.1: bool Stack<T, size> :: empty()
        Step 5.1.1: return top == -1

Step 6: declare template<typename T, int size>
    Step 6.1: void Stack<T, size> :: push(T element)
         Step 6.1.1: if (top == size - 1)
           Step 6.1.1.1: hrow out_of_range("Stack is Overload")
       Step 6.1.2: stack[++top] = element

Step 7: declare template<typename T, int size>
    Step 7.1: T Stack<T, size> :: pop()
        Step 7.1.1: if (empty())
          Step 7.1.1.1: throw out_of_range("Stack Under flow")
        Step 7.1.2: T element_popped = stack[top--]
        Step 7.1.3: return element_popped

Step 8: declare template<typename T, int size>
    Step 8.1: void Stack<T, size> :: display()
        Step 8.1.1: if (empty())
           Step 8.1.1.1: display "Stack is empty" 
           Step 8.1.1.2: return
        Step 8.1.2: for (int i = top; i >= 0; i--)
          Step 8.1.2.1:  display i

Step 9: int main()
    Step 9.1: const int stack_size = 10
    Step 9.2: Stack<int, stack_size> value
    Step 9.3: int choice
    Step 9.4: while(true)
        
        Step 9.4.1: display "MENU"
        Step 9.4.2: display "1. Push"
        Step 9.4.3: display "2. Pop"
        Step 9.4.4: display "3. Display"
        Step 9.4.5: display "4. Exit" 
        Step 9.4.6: display "Enter a choice: "
        Step 9.4.7: read choice
        Step 9.4.8: switch(choice)
            
            Step 9.4.8.1: case 1:
                
                Step 9.4.8.1.1: int element;
                Step 9.4.8.1.2: display "Enter element to push: "
                Step 9.4.8.1.3: read element
                Step 9.4.8.1.4: try
                    Step 9.4.8.1.4.1: value.push(element)
                    Step 9.4.8.1.4.2: display "Element pushed to stack
                
                Step 9.4.8.1.5: catch(const std::exception& e)
                    Step 9.4.8.1.5.1: std::cerr << e.what() 
                Step 9.4.8.1.6: break
            
            Step 9.4.8.2: case 2:
                Step 9.4.8.2.1: try
                    Step 9.4.8.2.1.1: int popped_element = value.pop();
                    Step 9.4.8.2.1.2: display "Top element in the Stack popped: " << popped_element 
                Step 9.4.8.2.2: catch(const std::exception& e)
                    Step 9.4.8.2.2.1: std::cerr << e.what() << '\n'
                Step 9.4.8.2.3: break
            
            Step 9.4.8.3: case 3:
                Step 9.4.8.3.1: display "Stack right now:"
                Step 9.4.8.3.2: value.display()
                Step 9.4.8.3.3: break
            
            Step 9.4.8.4: case 4
                Step 9.4.8.4.1: exit(0)
                Step 9.4.8.4.2: break
            
            Step 9.4.8.5:  default
                Step 9.4.8.5.1: display " You selected the wrong input please choose again." 
                Step 9.4.8.5.2: break
    
    Step 9.5: return 0

Step 10: STOP 
*/

#include<iostream>
using namespace std;

template <typename T, int size>
class Stack
{	 	  	 	   	      	    	  	 	
    private:
        T* stack;
        int top;
    public:
        Stack();
        ~Stack();

        bool empty();
        void push(T element);
        T pop();
        void display();
};

 template<typename T, int size>
   Stack<T, size> :: Stack()
   {
       stack = new T[size];
       top = -1;
   }
 template<typename T, int size>
   Stack<T, size> :: ~Stack()
   {
       delete[] stack;
   }
    template<typename T,  int size>
    bool Stack<T, size> :: empty()
    {
        return top == -1;
    }
 template<typename T, int size>
   void Stack<T, size> :: push(T element)
   {
       if (top == size - 1)
       {
           throw out_of_range("Stack is Overload");
       }	 	  	 	   	      	    	  	 	
       stack[++top] = element;
   }

   template<typename T, int size>
   T Stack<T, size> :: pop()
   {
       if (empty())
       {
           throw out_of_range("Stack Under flow");
       }

       T element_popped = stack[top--];
       return element_popped;
   }

   template<typename T, int size>
   void Stack<T, size> :: display()
   {
       if (empty())
       {
           cout << "Stack is empty" << endl;
           return;
       }
       for (int i = top; i >= 0; i--)
       {
           cout << stack[i] << " ";
       }
       cout << endl;
   }
   
int main()
{
    const int stack_size = 10;
    Stack<int, stack_size> value;
    int choice;
    while(true)
    {	 	  	 	   	      	    	  	 	
        cout << "MENU\n";
        cout << "1. Push";
        cout << "\n2. Pop";
        cout << "\n3. Display";
        cout << "\n4. Exit" << endl;
        cout << "Enter a choice: ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                int element;
                cout << "Enter element to push: ";
                cin >> element;
                try
                {
                    value.push(element);
                    cout << "Element pushed to stack\n";
                }
                catch(const std::exception& e)
                {
                    std::cerr << e.what() << '\n';
                }
            break;
            case 2:
                try
                {
                    int popped_element = value.pop();
                    cout << "Top element in the Stack popped: " << popped_element << endl;                
                }
                catch(const std::exception& e)
                {
                    std::cerr << e.what() << '\n';
                }
            break;
            case 3:
                cout << "Stack right now:\n";
                value.display();
            break;
            case 4:

                exit(0);
            break;
            default:
                cout << "\n You selected the wrong input please choose again.\n" << endl;
            break;
        }	 	  	 	   	      	    	  	 	
    }

    return 0;
}

/*  Expected (Input/Output) :-->

MENU
1. Push
2. Pop
3. Display
4. Exit
Enter a choice: 6

 You selected the wrong input please choose again.

MENU
1. Push
2. Pop
3. Display
4. Exit
Enter a choice: 1
Enter element to push: 10
Element pushed to stack
MENU
1. Push
2. Pop
3. Display
4. Exit
Enter a choice: 1
Enter element to push: 20
Element pushed to stack
MENU
1. Push
2. Pop
3. Display
4. Exit
Enter a choice: 1
Enter element to push: 30
Element pushed to stack
MENU
1. Push
2. Pop
3. Display
4. Exit
Enter a choice: 1
Enter element to push: 40
Element pushed to stack
MENU
1. Push
2. Pop
3. Display
4. Exit
Enter a choice: 1
Enter element to push: 50
Element pushed to stack
MENU
1. Push
2. Pop
3. Display
4. Exit
Enter a choice: 3
Stack right now:
50 40 30 20 10 
MENU
1. Push
2. Pop
3. Display
4. Exit
Enter a choice: 2
Top element in the Stack popped: 50
MENU
1. Push
2. Pop
3. Display
4. Exit
Enter a choice: 2
Top element in the Stack popped: 40
MENU
1. Push
2. Pop
3. Display
4. Exit
Enter a choice: 2
Top element in the Stack popped: 30
MENU
1. Push
2. Pop
3. Display
4. Exit
Enter a choice: 2
Top element in the Stack popped: 20
MENU
1. Push
2. Pop
3. Display
4. Exit
Enter a choice: 2
Top element in the Stack popped: 10
MENU
1. Push
2. Pop
3. Display
4. Exit
Enter a choice: 
2
Stack Under flow
MENU
1. Push
2. Pop
3. Display
4. Exit
Enter a choice: 4

*/	 	  	 	   	      	    	  	 	
