/*  Registration Number: 201900307 (Rishabh Chauhan)

AlGORITHM :-->

Step 1: Start

Step 2: Define a class COMPLEX 

Step 3: Initialise the class COMPLEX
    
    Step 3.1: Define integer variable real, img
    Step 3.2: In the Public Member:
        Step 3.2.1: Define a function input() to take input from the user
        Step 3.2.2: Define a function output() to display the output
        Step 3.2.3: Using the friend function call COMPLEX ADD(int,COMPLEX) & COMPLEX ADD(COMPLEX,COMPLEX)
                    
Step 4: In the COMPLEX ADD(int a, COMPLEX s2)
        temp.real <-- s2.real + a;
        temp.img <-- s2.img;

Step 5: In the COMPLEX ADD(COMPLEX s1, COMPLEX s2)
        s3.real <-- s1.real + s2.real;
        s3.img <-- s1.img + s2.img;

Step 6: In the main() function: 
    
    Step 6.1: Create objects s1,s2,sum1 & sum2
    Step 6.2: Get the input of the 1st & 2nd complex number from the user
    Step 6.3: Enter the value of a 
    Step 6.4: Calculate the sum of integer a with the complex number s2
    Step 6.5: Calculate the sum of both the complex numbers s1 & s2
    Step 6.6: Display the output
    
Step 7: Stop
*/

#include <iostream>
#include <math.h>
using namespace std;

class COMPLEX
{	 	  	 	   	      	    	  	 	
    int real;
    int img;
    public:
        void input()            // Takes input from the user
        {
            cout << "Enter the Real and Imag part" << '\n';
            cin >> real >> img;
        }
        void output()           // Displays output 
        {
            if(img<0)
            cout << real<< "i" <<img << '\n';
            else
            cout << real << "+" << img << "i" << '\n';
        }
        friend COMPLEX ADD(int,COMPLEX);
        friend COMPLEX ADD(COMPLEX,COMPLEX);
};

COMPLEX ADD(int a , COMPLEX s2)     // Calculates the sum of integer a with the complex number s2
{
    COMPLEX temp;
    temp.real = s2.real + a;
    temp.img = s2.img;
    return temp;
}

COMPLEX ADD(COMPLEX s1, COMPLEX s2) // Calculates the sum of both the complex numbers s1 & s2
{
    COMPLEX s3;
    s3.real = s1.real + s2.real;
    s3.img = s1.img + s2.img;
    return s3;
}

int main()
{	 	  	 	   	      	    	  	 	
    COMPLEX s1,s2,sum1,sum2;    // Create objects s1,s2,sum1 & sum2
    int a;

    s1.input();
    s2.input();
    cout << "\nFirst complex number (s1) is: "<< '\n';
    s1.output();
    cout << "Second complex number (s2) is: "<< '\n';
    s2.output();
    
    cout << "\nEnter the value of a : "<<'\n';
    cin >> a;
    sum1 = ADD(a,s2);
    sum2 = ADD(s1,s2);
    cout << "\nResult of ADD(a,s2) is: "<< '\n';
    sum1.output();
    cout << "Result of ADD(s1,s2) is: "<< '\n';
    sum2.output();

    return 0;
} 
