/*  Registration Number : 201900307 (Rishabh Chuahan)

(ALGORITHM) :-->

Step 1: Start

Step 2: Declare a class STACK:
    Step 2.1: Define int variables items[SIZE], top, full(), empty()
    Step 2.2: In public :
        Step 2.2.1: Define STACK() : top=-1
    Step 2.3: 
    
Step 3: Define int full()    //Check for Stack Overflow
    Step 3.1: if(top==SIZE-1)
                return 1;
              else
                return 0;

Step 4: Define int empty()  //Check for Stack Underflow
    Step 4.1: if(top==-1)
                return 1;
              else
                return 0;
                
Step 5: Define STACK STACK::operator--(int )   //function for element deletion from the stack

Step 6: Define STACK operator+(STACK s1,int elem)    //function for element insertion on to the stack

Step 7: In main() function: 
    Step 7.1: Using swtich case:
        Step 7.1.1: Display the choices 
        Step 7.1.2: Enter the choice from the user
        Step 7.1.3: Display the result as per the entered choices. 
*/

#include<iostream>
#include<stdlib.h>
using namespace std;

const int SIZE=5;       //Stack size

//class declaration
class STACK
{	 	  	 	   	      	    	  	 	
   int items[SIZE];
   int top;
   int full();
   int empty();
   public:
   STACK()
   {
      top=-1;
   }
   STACK operator--(int);
   friend STACK operator+(STACK s1,int elem);
   friend ostream &operator<<(ostream &os,STACK &s1);
};

// checking for Stack overflow
int STACK::full()
{
   if(top==SIZE-1)
      return 1;
   else
      return 0;
}

//Checking for stack under flow.
int STACK::empty()
{
   if(top==-1)
      return 1;
   else
      return 0;
}

//function for element deletion from the stack
STACK STACK::operator--(int )
{
   if(empty())
   {	 	  	 	   	      	    	  	 	
     cout<<"Stack underflow\n";
   }
   else
   {
       cout<<"The element deleted is :"<<items[top]<<endl;
       STACK t;
       t.top=--top;
       for(int i=0;i<=top;i++)
           t.items[i]=items[i];
   }
   return *this;
}

ostream &operator<<(ostream &os,STACK &s1)
{
   for(int i=s1.top;i>=0;i--)
     os<<s1.items[i]<<"\n";
   return os;
}

//function for element insertion on to the stack
STACK operator+(STACK s1,int elem)
{
   if(s1.full())
     cout<<"\nStack overflow\n";
   else
     s1.items[++(s1.top)]=elem;
   return s1;
}

/*Main function*/
int main()
{
   STACK s1;
   int choice,elem;
   
   while(1)
   {	 	  	 	   	      	    	  	 	
     cout<<"\n1:PUSH 2:POP 3:DISPLAY 4:EXIT\n"
     <<"\nEnter your choice: ";
     cin>>choice;
     
     switch(choice)
     {
       case 1:
           cout<<"Enter the element to be inserted: ";
           cin>>elem;
           s1=s1+elem;
           break;
           
       case 2:
           s1=s1--;
           break;
           
       case 3:
           cout <<"The contents of the stack are :\n"<<s1;
           break;
           
       case 4: exit(0);
       
       default: cout <<"Invalid choice\n";
       
       exit(0);
     }
   }
   return 0;
}

/*      Expected (Input/Output) :--> 

1:PUSH 2:POP 3:DISPLAY 4:EXIT                                                   
                                                                                
Enter your choice: 1                                                            
Enter the element to be inserted: 30                                            
                                                                                
1:PUSH 2:POP 3:DISPLAY 4:EXIT                                                   
                                                                                
Enter your choice: 1                                                            
Enter the element to be inserted: 40                                            
                                                                                
1:PUSH 2:POP 3:DISPLAY 4:EXIT                                                   
                                                                                
Enter your choice: 2                                                            
The element deleted is :40                                                      
                                                                                
1:PUSH 2:POP 3:DISPLAY 4:EXIT                                                   
                                                                                
Enter your choice: 3                                                            
The contents of the stack are :                                                 
30                                                                              
                                                                                
1:PUSH 2:POP 3:DISPLAY 4:EXIT  

Enter your choice: 
*/	 	  	 	   	      	    	  	 	
