/*  Registration Number : 201900307 (Rishabh Chauhan)

ALGORITHM :-->

Step 1: Start

Step 2: Declare a class OVERLOAD

Step 3: Declare the public members

Step 4: Declare a function int add () to add two integer parameters
    Step 4.1: returns the sum of both the integers

Step 5: Declare a function double add () to add two double parameters
    Step 5.1: returns the sum of both the double parameters

Step 6: Declare a function int add () to add three integer parameters
    Step 6.1: returns the sum of all the three integer parameters

Step 7: Declare a function double add () to add three double parameters
    Step 7.1: returns the sum of all the double parametrs

Step 8: Declare a function double add () to add first integer parameter & second double parameter
    Step 8.1: return the sum of integer and double parameter

Step 9: Declare a function double add () to add first double parameter & second integer parameter
    Step 9.1: returns the sum of double and integer parameter

Step 10: In the main():
    Step 10.1: call the functions by their respective parameters
    Step 10.2: Display the output
    
Step 11: Stop.

*/

#include<iostream>
using namespace std;

#include<iostream>
using namespace std;

class OVERLOAD
{	 	  	 	   	      	    	  	 	
   public: 

    int add(int a , int b)
    {
        cout<<"\n Passing two intergers parameters ";
        return (a+b);
    }
    
    double add (double a, double b)
    {
        cout<<"\n Passing two Double parameters ";
        return (a+b);
    }
    
    int add(int a, int b, int c)
    {
        cout<<"\n Passing three integer parameters ";
        return (a+b+c);
    }

    double add(double a, double b, double c)
    {
        cout<<"\n Passing three double parameters ";
        return (a+b+c);
    }
    
    double add (int a, double b)
    {
        cout<<"\n Passing first parameter as interger and second as double ";
        return (a+b);
    }

    double add (double a, int b)
    {
    cout<<"\n Passing first parameter as double and second as integer ";
    return (a+b);
    }	 	  	 	   	      	    	  	 	
}
obj;

int main()
{
    
  cout<<obj.add(6,2)<<endl;
  
  cout<<obj.add(5.4,2)<<endl;
  
  cout<<obj.add(2,3,4)<<endl;
  
  cout<<obj.add(3.2,3.2,3.3)<<endl;
  
  cout<<obj.add(7,2,1)<<endl;
  
  cout<<obj.add(9,8.4)<<endl;

}

/*  INPUT/OUTPUT :-->


 Passing two intergers parameters 8                                             
                                                                                
 Passing first parameter as double and second as integer 7.4                    
                                                                                
 Passing three integer parameters 9                                             
                                                                                
 Passing three double parameters 9.7                                            
                                                                                
 Passing three integer parameters 10                                            
                                                                                
 Passing first parameter as interger and second as double 17.4  
 
 */
	 	  	 	   	      	    	  	 	
