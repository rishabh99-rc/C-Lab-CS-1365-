/*  Registration Number : 201900307 (Rishabh Chauhan)

Step 1: Start

Step 2: Define a class student:
    Step 2.1: Declare public variables reg, age, name[20]
    Step 2.2: Call the function read_data()
    
Step 3: Define a derived class ugstudent (of the parent class student)
    Step 3.1: Declare public variables stipend, sem, fees
    Step 3.2: Call the function read_data()

Step 4: Define a derived class pgstudent (of the parent class student)
    Step 4.1: Declare public variables stipend, sem, fees
    Step 4.2: Call the function read_data()
    
Step 5: In the function read_data for the parent class student:
    Step 5.1: Take input from the user : Name, Reg.No, age
    
Step 6: In the function read_data of the derived class ugstudent:
    Step 6.1: Take input from the user : sem, fees, stipend    

Step 7: In the function read_data of the derived class pgstudent:
    Step 7.1: Take input from the user : sem, fees, stipend
    
Step 8: In int main():
    Step 8.1: get the number of entries from the user
    Step 8.2: using the read_data() function read the data from the user
    Step 8.3: calculate the average age of the students having similar semesters   // (avg = sum/count)
    
Step 9: Stop    
*/


#include<iostream> 
using namespace std;

class student 
{	 	  	 	   	      	    	  	 	
    public:  int reg,age; 
        char name[20]; 
        void read_data(); 
}; 

class ugstudent:public student 
{ 
    public:  int stipend,sem; 
        float fees; 
        void read_data(); 
}; 


class pgstudent:public student 
{ 
    public:  int stipend,sem; 
        float fees; 
        void read_data(); 
}; 

/* function to read student details*/ 
void student::read_data() 
{ 
    cout<<"\n Enter name:"; 
    cin>>name; 
    cout<<"\n Enter Reg.no."; 
    cin>>reg; 
    cout<<"\n Enter age:"; 
    cin>>age;  
 }
 
void ugstudent::read_data() 
{ 
    student::read_data(); 
    cout<<"\nEnter the sem:"; 
    cin>>sem; 
    cout<<"\nEnter the fees:"; 
    cin>>fees; 
    cout<<"\nEnter the stipend:"; 
    cin>>stipend; 
}	 	  	 	   	      	    	  	 	

/* function to read additional details for pgstudents*/ 
void pgstudent::read_data() 
{ 
    student::read_data(); 
    cout<<"\nEnter the sem:"; 
    cin>>sem; 
    cout<<"\nEnter the fees:"; 
    cin>>fees; 
    cout<<"\nEnter the stipend:"; 
    cin>>stipend; 
} 

/* main function */ 
int main() 
{ 
    ugstudent ug[20]; 
    pgstudent pg[20]; 
    
    int i,n,m; 
    float average;
    
    cout<<"\nEnter the no. of entries in the ugstudent class:"; 
    cin>>n; 
    
    for(i=1;i<=n;i++) 
        ug[i].read_data(); 
    
    for(int sem=1;sem<=8;sem++) 
    { 
        float sum=0; 
        int found=0,count=0; 
        for(i=1;i<=n;i++) 
        { 
            if(ug[i].sem==sem) 
            {	 	  	 	   	      	    	  	 	
                sum=sum+ug[i].age; 
                found=1;
                count++; 
            } 
        } 
    if(found==1) 
    { 
        average=sum/count; 
        cout<<"\nAverage of age of sem "<<sem<<" is "<<average; 

    } 
    } 
    
    cout<<"\nEnter the no. of entries of pgstudent class:"; 
    cin>>n; 
    
    for(i=1;i<=n;i++) 
        pg[i].read_data(); 
    for(int sem=1;sem<=8;sem++) 
    { 
        float sum=0; 
        int found=0,count=0; 
        for(i=1;i<=n;i++) 
        { 
            if(pg[i].sem==sem) 
            { 
                sum=sum+pg[i].age; 
                found=1; 
                count++; 
            } 
        } 
    if(found==1) 
    { 
        average=sum/count; 
        cout<<"\nAverage of age of sem "<<sem<<" is "<<average; 
    }	 	  	 	   	      	    	  	 	
    } 
    return 0;
} 

/* Expected (Input/Output) :-->

Enter the no. of entries in the ugstudent class:2                               
                                                                                
 Enter name:rishabh                                                             
                                                                                
 Enter Reg.no.201900307                                                         
                                                                                
 Enter age:20                                                                   
                                                                                
Enter the sem:3                                                                 
                                                                                
Enter the fees:300000                                                           
                                                                                
Enter the stipend:20000                                                         
                                                                                
 Enter name:nikhil                                                              
                                                                                
 Enter Reg.no.201900310                                                         
                                                                                
 Enter age:19                                                                   
                                                                                
Enter the sem:3                                                                 

Enter the fees:300000                                                           
                                                                                
Enter the stipend:20000   

Average of age of sem 3 is 19.5

Enter the no. of entries in the pgstudent class:2                               
                                                                                
 Enter name:rohan                                                             
                                                                                
 Enter Reg.no.201800407                                                         
                                                                                
 Enter age:24                                                                   
                                                                                
Enter the sem:5                                                                 
                                                                                
Enter the fees:500000                                                           
                                                                                
Enter the stipend:50000                                                         
                                                                                
 Enter name:raj                                                              
                                                                                
 Enter Reg.no.201800310                                                         
                                                                                
 Enter age:25                                                                   
                                                                                
Enter the sem:5                                                                 

Enter the fees:500000                                                           
                                                                                
Enter the stipend:50000   

Average of age of sem 3 is 24.5

*/	 	  	 	   	      	    	  	 	
