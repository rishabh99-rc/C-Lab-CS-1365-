/* Reg No: 201900307 (Rishabh Chauhan)

ALGORITHM:-->

Step 1: Start

Step 2: Define SIZE as 10

Step 3: Declare a class student 

Step 4: Initialize the class student

    Step 4.1: Declare name[20], usn[10], integer variables as marks1, marks2, marks3.
    Step 4.2: Declare read() and display() function as public

Step 5: In read() function: read name, usn & marks in 3 test subjects

Step 6: In display() function: calculate the average of two better marks
                               display name, usn & avg
                               
Step 7: In main() function: Declare an object ob[SIZE]
                            Display "Student Report"
                            Display "Enter the number of students"
                            Read all the details from the read() function
                            Display "Student Details"
                            for (i=0; i<n; i++)
                                Display the details from the display() function
                                
Step 8: Stop
*/

#include <iostream>
#define SIZE 10         // Size of Student objects
using namespace std;

class student           //Defining a class Student
{	 	  	 	   	      	    	  	 	
    char name[20], usn[10];
    int marks1,marks2,marks3;
    
    public:
    void read();
    void display();
};

void student :: read()              // Declaring a function to read all the details
{
    cout<<"Enter the Name: "<<endl;
    cin>>name; 
    cout<<"Enter student USN: "<<endl;
    cin>>usn;
    cout<<"Enter the marks in all three subjects: "<<endl;
    cin>>marks1>>marks2>>marks3;
}

void student :: display()           // Declaring a function to display all the details 
{
    float avg, low=marks3;
    if(marks2<low)
        low=marks2;
    else if(marks3<low)
        low=marks3;
    avg=(marks1+marks2+marks3-low)/2;   // Calculating the average of two better marks for each student
    
    cout<<"Name: "<<name<<endl;
    cout<<"Students USN: "<<usn<<endl;
    cout<<"The Average Marks: "<<avg<<endl;
}

int main()
{
    
    student ob[SIZE];
    int n;
    
    cout<<"\n";
    cout<<"\n*******************************"
        <<"\n        STUDENT REPORT"
        <<"\n*******************************"
        <<"\nEnter the number of students: ";
    cin>>n;
    
    for(int i=0;i<n;i++)
    {	 	  	 	   	      	    	  	 	
        ob[i].read();
    }
    
    cout<<"\n-----------------"
    <<"\nStudent Details::"
    <<"\n-----------------";
    
    for(int i=0;i<n;i++)
    {
        cout<<"\n\nStudent:"<<i+1
        <<"\n";
        ob[i].display();
    }
    return 0;
}