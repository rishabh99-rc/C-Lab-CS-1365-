/*  REGISTRATION NUMBER : 201900307 (Rishabh Chauhan)

ALGORITHM :-->

Step 1: Start

Step 2: Declare the class with name Twovalues
    Step 2.1: Declare the two variables int a,int b under protected access specifier
	Step 2.2: In userdefined inline function input()
	         Step 2.2.1: Display  Enter the value for A and read as a
			 Step 2.2.2: Display  Enter the value for B and read as b
			 Step 2.2.3: Return 0
	Step 2.3: Declare friend class Min_Max

Step 3: In class Min_Max
    Step 3.1: Declare the userdefined functions int minimum(Twovalues),int maximum(Twovalues)

Step 4: In main() function
    Step 4.1: Declare two objects Twovalues obj,Min_Max obj1
    Step 4.2: Compute obj.input(),obj1.maximum(obj),obj1.minimum(obj)
    Step 4.3: Return 0

Step 5: In maximum(Two values obje1) function
    Step 5.1: Compute if(obje1.a>obje1.b)
	  	                  Display obje1.a is Maximum
	                   else
	  	                  Display obje1.b is Maximum
	Step 5.2: Return 0

Step 6: In minimum(Twovalues obje2)
    Step 6.1: Compute 	if(obje2.a<obje2.b)
	                       Display obje2.a is Minimum
	                    else
	  	                   Display obje2.b is Minimum
	Step 6.2: Return 0

Step 7: Stop
*/

#include<iostream>
using namespace std;

class Twovalues
{	 	  	 	   	      	    	  	 	
	protected:
		int a;
		int b;
	public:
		inline int input()
		{
			cout<<"\nEnter the value of A\n";
			cin>>a;
			cout<<"\nEnter the value of B\n";
			cin>>b;
		}
	friend class Min_Max;
};

class Min_Max
{
	public:
		int minimum(Twovalues);
		int maximum(Twovalues);
};

int main()
{
	Twovalues obj;
	Min_Max obj1;
	obj.input();
	obj1.maximum(obj);
	obj1.minimum(obj);
	return 0;
}

int Min_Max :: maximum(Twovalues obje1)
{
	if(obje1.a>obje1.b)
	  {
	  	cout<<obje1.a<<" is Maximum"<<endl; 	  
	  }	 	  	 	   	      	    	  	 	
	else
	  {
	  	cout<<obje1.b<<" is Maximum"<<endl;
	  }
	return 0;
}

int Min_Max :: minimum(Twovalues obje2)
{
	if(obje2.a<obje2.b)
	  {
	  	cout<<obje2.a<<" is Minimum"<<endl;
	  }
	else
	  {
	  	cout<<obje2.b<<" is Minimum"<<endl;
	  }
	return 0;
}

/*  Expected ( INPUT / OUTPUT ) :-->

Enter the value of A
12

Enter the value of B
13

13 is Maximum
12 is Minimum

*/	 	  	 	   	      	    	  	 	
