/*  Registration Number: 201900307 (Rishabh Chauhan)

Algorithm :-->

Step 1: Start
            
Step 2: Declare a class C_POWER
            
Step 3: Initialise the class C_POWER
            
Step 4: Declare the function power using the public access specifier
        which raises a double value of m to the power n and if the
        value of n not specified, the it is taken to be as 2 and then
        print the answer

Step 5: Declare another function power using the public access specifier
        which raises an integer value of m to the power n and if the
        value of n not specified, the it is taken to be as 2 and then
        print the answer

Step 6: Create a main function to create an object of the class, input
        the required values and then call the respective functions as
        required
            
Step 7: Stop
*/

#include<iostream>
#include<math.h>
using namespace std;

class C_POWER                                   // class C_power which contains the overloaded function power
{
    public:
            void power(double m, int n=2)       // power function where the value of m is double
            {
                double res=0;
                res=pow(m,n);
                cout<<"\nResult when the power is 2 (i.e n=2) = "<<res<<"\n";
            }	 	  	 	   	      	    	  	 	
           
            void power(int m, int n=2)          // power function where the value of m is integer
            {
                int res=0;
                res=pow(m,n);
                cout<<"\nResult when the power is an integer = "<<res<<"\n";
            }
};

int main()                                  
{
    double m1;                  // variable declaration
    int n,m2;
   
    C_POWER obj;                // Creating the object of the class
   
    cout<<"Enter a value of type double(for m): ";
    cin>>m1;
    
    cout<<"\nEnter the power of the number (for n): ";
    cin>>n;
    
    cout<<"\nEnter a value of type int(for m): ";
    cin>>m2;
    
    
    obj.power(m1,n);
    obj.power(m2,n);
    
    obj.power(m1);       //calling the respective functions as required using the object of the class
    obj.power(m2);
    
   
    return 0;
}	 	  	 	   	      	    	  	 	
