/*  Registration Number: 201900307 (Rishabh Chauhan)

ALGORITHM:-->

Step 1: Start

Step 2: Declare class Student

Step 3: Initialise class Student
    Step 3.1: Initialise integer variable Regn_No
              Initialise character variable Name
              Initialise float variable S1, S2, S3, avg
              
    Step 3.2: Apply an access specifier as public
        Step3.2.1: Initialise member function
                   1. void read(): To read Regn_No, Name, S1, S2, S3
                   2. float average_marks(): Compute avg = (S1+S2+S3)/3.0;
                   3. void display(): To display Regn_No, Name, S1, S2, S3, avg
                   
Step 4: In the main function()
    Step 4.1: Create an object "s1" under the class Employee (Accessing through member function)
        s1.read()
        s1.average_marks()
        s1.display()
        
    Step 4.2: Create an object "s2" under the class Employee (Accessing through member function)
        s2.read()
        s2.average_marks()
        s2.display()
   
   Step 4.3: Create an object "s3" under the class Employee (Accessing through member function)
        s3.read()
        s3.average_marks()
        s3.display()
        
Step 5: Stop. 

*/

#include <iostream>

using namespace std;

class Student{                              // Declaring class Student

    int Regn_No;                            // Initialising Data Members
    char Name[20];
    float S1,S2,S3,avg;

    public:
        void read();                        // Initialising Member Functions
        void display();
        float average_marks();
};

     void Student :: read()                 // Function to read the Data Members 
    {	 	  	 	   	      	    	  	 	

        cout << "Enter the Registration Number: ";
        cin >> Regn_No;
        cout << "\nEnter the Name of the student: ";
        cin >> Name;
        cout << "\nEnter the marks in three subjects:\n";
        cout <<"Subject 1: ";
        cin >> S1;
        cout <<"\nSubject 2: ";
        cin >> S2;
        cout <<"\nSubject 3: ";
        cin >> S3;

    }
    
    float Student :: average_marks()        // Function to calculate average marks
    {
        avg = (S1+S2+S3)/3.0;
        return avg;
    }
    
    void Student :: display()               // Function to display the Data Members
    {
        cout << "\nStudent's Name: "<<Name;
        cout << "\nRegistration Number: "<<Regn_No;
        cout << "\nMarks in - Subject 1: "<<S1 <<"\tSubject 2: "<<S2<<"\tSubject 3: "<<S3;
        cout << "\nAverage marks: "<<avg;
        cout <<"\n_____\n";
    }


int main()
{
    Student s1,s2,s3;                       // Initialising object in main() function
    
    s1.read();
    s2.read();
    s3.read();
    
    s1.average_marks();
    s2.average_marks();
    s3.average_marks();
    
    s1.display();
    s2.display();
    s3.display();

    return 0;
}	 	  	 	   	      	    	  	 	