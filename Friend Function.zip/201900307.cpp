/*  Registration Number : 201900307 (Rishabh Chauhan)

ALGORITHM :-->

Step 1: Start

Step 2: Declare two class DB & DM

Step 3: In class DM:
    Step 3.1: Declare two float variables meter & centi 
    
    Step 3.2: In void getdata():
        Step 3.2.1: Get the input from the user (in meter & centimeter)
    
    Step 3.3: In void display():
        Step 3.3.1: Display the output entered by the user
        
    Step 3.4: Using a friend function add():
        Step 3.4.1: Add one object of the DM class with the other object of the DB class

Step 4: In class DB: 
    Step 4.1: Declare two float variables meter & centi 
    
    Step 4.2: In void getdata():
        Step 4.2.1: Get the input from the user (in inch & feet)
    
    Step 4.3: In void display():
        Step 4.3.1: Display the output entered by the user
        
    Step 4.4: Using a friend function add():
        Step 4.4.1: Add one object of the DM class with the other object of the DB class

Step 5: In void add(DM &a,DB &b):
    Step 5.1: To add the object of both the class as per the choice entered by the user.
    
Step 6: In main():
    Step 6.1: Declare two object a & b for the class DM & DB respectively. 
    
    Step 6.2: get the data from the user & dislay the result accordingly. 

Step 7: Stop
*/

#include<iostream>
using namespace std;

class DB;
class DM        // Declaring the class for meter-centimeter
{	 	  	 	   	      	    	  	 	
    float meter,centi;
    public:
    
    void getdata()
    {
        cout<<"\nEnter the distance in(meter-centimeter):";
        cin>>meter>>centi;
    }
 
    void display()
    {
        cout<<"\nThe distance is:";
        cout<<meter<<" meters and "<<centi<<" centimeter";
    }
    
    friend void add(DM &,DB &);
};

class DB        // Declaring the class for feet-inch
{
    float inch,feet;
    public:
    
    void getdata()
    {
        cout<<"\nEnter the distance in(feet-inch):";
        cin>>feet>>inch;
    }
 
    void display()
    {
        cout<<"\nThe distance is:";
        cout<<feet<<" feet and "<<inch<<" inch";
    }
 
    friend void add(DM &,DB &);
};

void add(DM &x,DB &y)       // To add one object of DM with another object of DB
{	 	  	 	   	      	    	  	 	
    int ch;
    cout<<"\nPress 1 for meter-centi:";
    cout<<"\nPress 2 for feet-inch:";
    cout<<"\nEnter your choice:";
    cin>>ch;
    
    if(ch==1)
    {
        DM d;
        int c=(x.meter*100+x.centi+y.feet*30.48+y.inch*2.54);
        if(c>=100)
        {
            d.meter=c/100;
            d.centi=c%100;
        }
        else
        {
            d.meter=0;
            d.centi=c;
        }
        d.display();
    }
 
    else
    {
        DB d;
        int i=(x.meter*39.37+x.centi*.3937008+y.feet*12+y.inch);
        if(i>=12)
        {
            d.feet=i/12;
            d.inch=i%12;
        }
        else
        {
            d.feet=0;
            d.inch=i;
        }	 	  	 	   	      	    	  	 	
        d.display();
    }
}

int main()
{
    DM x;
    DB y;
    
    x.getdata();
    y.getdata();
    add(x,y);
    
    return 0;

}
/*  Expected (INPUT/OUTPUT) : 

Enter the distance in(meter-centimeter):5 6                                     
                                                                                
Enter the distance in(feet-inch):4 9                                            
                                                                                
Press 1 for meter-centi:                                                        
Press 2 for feet-inch:                                                          
Enter your choice:1                                                             

The distance is:6 meter and 50 centimeters                                                                
*/	 	  	 	   	      	    	  	 	
