/*  Registration Number : 201900307(Rishabh Chauhan) 

ALGORITHM :-->

Step 1: Start

Step 2: Declare a class Bank:
    Step 2.1: Initialise char variable name[20], atype[20], integer variable ano, & float variable bal
    
    Step 2.2: In public:
        Step 2.2.1: Declare void get()  // To input name & account type from the user
        Step 2.2.2: Declare float deposit() // To input the amount the user wishes to deposit
        Step 2.2.3: Declare float withdrw() // To input the amount the user wishes to withdraw
        Step 2.2.4: Declare void disp() // To display the account details
        
Step 3: Define trans =0;

Step 4: In main(): 
    Step 4.1: Declare an object bk 
    Step 4.2: Take the bank details from the user

Step 5: Stop
*/

#include<iostream>
#include<string.h>

using namespace std;

class Bank
{
    char name[20];
    int ano;
    char atype[20];
    float bal;
    
    public:
    static int trans; 
    
    void get(int no,char *n,char *t,float b)    // To input name & account type from the user
    {	 	  	 	   	      	    	  	 	
        strcpy(name,n);
        ano=no;
        strcpy(atype,t);
        bal=b;
    }

    float deposit()                             // To input the amount the user wishes to deposit
    {
        float amt;
        cout<<"\nEnter amount you wish to deposit: ";
        cin>>amt;
        bal=bal+amt;
        return bal;
    }

    float withdrw()                             // To input the amount the user wishes to withdraw
    {
        float amt;
        cout<<"\nHow much do you wish to withdraw: ";
        cin>>amt;
        bal=bal-amt;
        return bal;
    }

    void disp()                                 // To display the account details
    {
        trans++;
        cout<<"\n\nAccount number: "<<ano;
        cout<<"\nName: "<<name;
        cout<<"\nAccount type: "<<atype;
        cout<<"\n\nNet Balance after Deposit: "<<deposit();
        cout<<"\n\nAfter Withdraw Amount balance: "<<withdrw();
        cout<<"\n\nNumber of Transaction = "<<trans;
    }
};

int Bank :: trans=0;
int main()
{	 	  	 	   	      	    	  	 	
    int n;
    char nm[20],t[20];
    float a;
    Bank bk;    // Declaring an object 
    
    cout<<"***** ENTER YOUR BANK DETAILS *****";
    cout<<"\nEnter Account no.: "; cin>>n;
    cout<<"\nEnter Name: "; cin>>nm;
    cout<<"\nEnter Account type: "; cin>>t;
    cout<<"\nEnter Balance amount: ";cin>>a;
    
    bk.get(n,nm,t,a);
    bk.disp();
    
    return 0;
}

/*  Expected Input/Output

***** ENTER YOUR BANK DETAILS *****                                             
Enter Account no.: 000021365                                                    
                                                                                
Enter Name: Rishabh                                                             
                                                                                
Enter Account type: Savings                                                     
                                                                                
Enter Balance amount: 50000                                                     
                                                                                
                                                                                
Account number: 21365                                                           
Name: Rishabh                                                                   
Account type: Savings                                                           
Enter amount you wish to deposit: 5000                                          
                                                                                
                                                                                
Net Balance after Deposit: 55000                                                
How much do you wish to withdraw: 20000                                         
                                                                                
                                                                                
After Withdraw Amount balance: 35000                                            
                                                                                
Number of Transaction = 1
*/	 	  	 	   	      	    	  	 	
