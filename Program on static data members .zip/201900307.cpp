/*  Registration Number : 201900307 

Step 1: Start 

Step 2: Declare the class Data
         
Step 3: Initialise the class Data:
    
    Step 3.1: In the private data members: 
        Step 3.1.1: Declare an int data type regNo & a char data type name[20]
    
    Step 3.2: In the public data members: 
        Step 3.2.1: Declare a static integer data member objectCount
        
    Step 3.3: Declare void getdata() to get the data from the user
    
    Step 3.4: Declare void disdata() to diaplay the data entered by the user

Step 4: In main() function: 
    
    Step 4.1: Declare 3 objects 
    Step 4.2: Call them one by one using getdata() & disdata() member functions
    Step 4.2: Display the total number of objects created

Step 5: Stop
*/

#include <iostream>
#include<string.h>

using namespace std;

class Data 
{   private:
    int regNo;
    char name[20];
    
    public:
    static int objectCount;
    Data() 
    {	 	  	 	   	      	    	  	 	
        objectCount++;
    }

   void getdata()                       // Enter the input from the user
   {
        cout << "\nEnter Reg No: "<<endl;
        cin >> regNo;
        cout << "Enter Name: "<<endl;
        cin >> name;
   }

   void disdata()                       // Display the input entered by the user
   {
        cout<<"\nReg Number = "<< regNo <<endl;
        cout<<"Name = "<< name <<endl;
        cout<<endl;
   }
};

int Data :: objectCount = 0;

int main() 
{
    cout << "***** Demonstrate Static Members Of a Class *****"<<endl;
    
    Data s1;
    s1.getdata();
    s1.disdata();
   
    Data s2;
    s2.getdata();
    s2.disdata();
    
    Data s3;
    s3.getdata();
    s3.disdata();
   
   
    cout << "Total objects created = " << Data :: objectCount << endl;    // Display the number of output
   
    return 0;
}	 	  	 	   	      	    	  	 	

/*  Expected Input/Output :-->

****** Demonstrate Static Members Of a Class *****                               
                                                                                
Enter Reg No:                                                                   
201900307                                                                       
Enter Name:                                                                     
Rishabh                                                                         
                                                                                
Reg Number = 201900307                                                          
Name = Rishabh                                                                  
                                                                                
                                                                                
Enter Reg No:                                                                   
201900205                                                                       
Enter Name:                                                                     
Kamran                                                                          
                                                                                
Reg Number = 201900205                                                          
Name = Kamran                                                                   
                                                                                
                                                                                
Enter Reg No:                                                                   
201900392                                                                       
Enter Name:                                                                     
Nikhil

Total objects created = 3
*/
	 	  	 	   	      	    	  	 	
