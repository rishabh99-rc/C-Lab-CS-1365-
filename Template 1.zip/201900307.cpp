/*  Registration Number : 201900307 (Rishabh Chauhan)

Algorithm :-->

Step 0: START

Step 1: Declare template <typename BB>

Step 2: void show(int n,BB ar[])

Step 3: template <typename tempa>

Step 4: void Bubble_sorting(int n,tempa ar[])
    Step 4.1: tempa temp
    Step 4.2: display "Before sorting elements are:"
    Step 4.3: show(n,ar)
    Step 4.4: for(int i=0;i<n-1;i++)
        
        Step 4.4.1: for(int a=0;a<n-i-1;a++)
            Step 4.4.1.1: if(ar[a]>ar[a+1])
                
                Step 4.4.1.1.1: temp=ar[a]
                Step 4.4.1.1.2: ar[a]=ar[a+1]
                Step 4.4.1.1.3: ar[a+1]=temp
    
    Step 4.5: display "After sorting:"
    Step 4.6: show(n,ar)

Step 5: declare template <class BB>

Step 6: void show(int n,BB ar[])
    Step 6.1: for(int j=0;j<n;j++)
        Step 6.1.1: display ar[j]

Step 7: int main()
    Step 7.1: int choice,n
    Step 7.2: float ab[100]
    Step 7.3: while (1)
        
        Step 7.3.1: display "MENU"
        Step 7.3.2: display "1.Enter element"
        Step 7.3.3: display "2.Exit"
        Step 7.3.4: display "Enter your choice:  "
        Step 7.3.5: cin>>choice
        Step 7.3.6: switch (choice)
            
            Step 7.3.6.1: case 1: display "Enter the no. elements:  "
                    Step 7.3.6.1.1: read n;
                    Step 7.3.6.1.2: display "Enter element: "
                    Step 7.3.6.1.3: for(int j=0;j<n;j++)
                    Step 7.3.6.1.4: read ab[j]
                    Step 7.3.6.1.5: Bubble_sorting(n,ab)
            Step 7.3.6.2: case 2: exit(0)
                    Step 7.3.6.2.1: break
            Step 7.3.6.3: default:
                Step 7.3.6.3.1: display " You selected the wrong input please choose again."
    
    Step 7.4: return 0

Step 8: STOP 
*/

#include<iostream>
using namespace std;

template <typename BB>
void show(int n,BB ar[]);
template <typename tempa>
void Bubble_sorting(int n,tempa ar[])
{	 	  	 	   	      	    	  	 	
    tempa temp;
    cout<<"\nBefore sorting elements are:";
    show(n,ar);
    for(int i=0;i<n-1;i++)
    {
        for(int a=0;a<n-i-1;a++)
        {
            if(ar[a]>ar[a+1])
            {
                temp=ar[a];
                ar[a]=ar[a+1];
                ar[a+1]=temp;
            }
        }

    }
    cout<<"\nAfter sorting:\n";
    show(n,ar);
}

template <class BB>
void show(int n,BB ar[])
{
    cout<<endl;
    for(int j=0;j<n;j++)
    {
        cout<<ar[j]<<"\t";
    }
}

int main()
{
    int choice,n;
    float ab[100];
    while (1)
    {	 	  	 	   	      	    	  	 	
        cout<<"\n*MENU*";
        cout<<"\n1.Enter element";
        cout<<"\n2.Exit";
        cout<<"\n";
        cout<<"\nEnter your choice:  ";
        cin>>choice;
        switch (choice)
        {
            case 1: cout<<"\nEnter the no. elements:";
                    cin>>n;
                    cout<<"\nEnter element: \n";
                    for(int j=0;j<n;j++)
                    cin>>ab[j];
                    Bubble_sorting(n,ab);

            case 2: exit(0);
                    break;
            default:
                cout<<" \n You selected the wrong input please choose again.\n";
        };
    }
    return 0;
}

/*
Expected (Input/Output)

MENU
1.Enter element
2.Exit

Enter your choice:  1

Enter the no. elements:6

Enter element: 
5
9
12
1
8
99

Before sorting elements are:
5	9	12	1	8	99	
After sorting:

1	5	8	9	12	99	

*/	 	  	 	   	      	    	  	 	
