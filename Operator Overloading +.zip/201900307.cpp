/*  Registration Number : 201900307 (Rishabh Chauhan)

ALGORITHM:-->

Step 1: Start

Step 2: Create class Complex

    Step 2.1: Declare private members float real adn float imag
    Step 2.2: Declare public section
    Step 2.3: Define a default constructor assigning real=0 and imag=0
    Step 2.4: Define input() which reads the value of real and imag
    
    Step 2.5: Define a function Complex operator +(Complex c2)
        Step 2.5.(i): declare Complex temp
        Step 2.5.(ii): temp.real = real + c2.real
        Step 2.5.(iii): temp.imag = imag + c2.imag
        Step 2.5.(iv): return temp
    
    Step2.6: Define a function Complex operator +(int a)
        Step 2.6.(i): declare Complex temp
        Step 2.6.(ii): temp.real = real + a
        Step 2.6.(iii): temp.imag = imag + 0
        Step 2.6.(iv): return temp  
    
    Step 2.7: Define output() which displays the values of real and imag

Step 3: Define main()
    
    Step3.1: Declare Complex c1, c2,result,result1. Declare int a
    Step3.2: Read the values of c1,c2 and a
    Step3.3: result=c1+c2
    Step3.4: result1=c2+a
    Step3.5: Call result.output()
    Step3.6: Call result1.output()

Step 4: Stop
*/

#include <iostream>
using namespace std;

class Complex
{	 	  	 	   	      	    	  	 	
    private:
      float real;
      float imag;
      
    public:
       Complex()
	   {
	   		real=0;
	   		imag=0;
	   }
       void input()
       {
           cout << "Enter real and imaginary parts respectively: ";
           cin >> real;
           cin >> imag;
           
       }
           
       
       Complex operator + (Complex s2)
       {
           Complex temp;
           temp.real = real + s2.real;
           temp.imag = imag + s2.imag;
                 
           return temp;
       }
       
       Complex operator + (int a)
       {
           	Complex temp;
        	temp.real=real+a;
        	temp.imag=imag+0;  
           return temp;
       }

       void output()
       {	 	  	 	   	      	    	  	 	
           
                cout << "Output Complex number: "<< real <<"+"<< imag << "i"<<endl;
              
       }
     
};

int main()
{
    Complex s1, s2,result,result1;
    int a;
    cout<<"Enter first complex number:\n";
    s1.input();

    cout<<"Enter second complex number:\n";
    s2.input();
    cout<<"Enter the value of integer:\n";
    cin>>a;
    
    result = s1 + s2;
    result1 = s2 + a;
    result.output();
    cout<<"\t**Adding integer with the second complex no**"<<endl;
    result1.output();

    return 0;
}

/*  Input/Output :-->

Enter first complex number:                                                     
Enter real and imaginary parts respectively: 5 8                                
Enter second complex number:                                                    
Enter real and imaginary parts respectively: 7 4                                
Enter the value of integer:                                                     
5                                                                               
Output Complex number: 12+12i                                                   
        **Adding integer with the second complex no**                           
Output Complex number: 12+4i 
*/	 	  	 	   	      	    	  	 	
